EN >>> You�ve just downloaded Urania Czech font made of old German Urania typewriter with Czech symbols.     

Urania Czech font was created by Lukas Krakora and is free for non-commercial use only.

If you want to use this font commercially, please contact me at: krraaa@yahoo.com to get the information about pricing.

Please type "Urania Czech" in subject of your message.

I will also appreciate to receive any comments or pictures of your artwork using this font at the same address.  

Please feel free to distribute this font, but keep this readme file with it and do not change the font in any way!

Have fun! 

PS. If you type alt-1, original logo of Urania typewriter will show up.



CZ >>> Prave jste si stahli font Urania Czech, vytvoreny dle stareho nemeckeho psaciho stroje Urania s ceskymi znaky.

Font Urania Czech byl vytvoren Lukasem Krakorou a je volne ke stazeni a pouziti avsak pouze pro nekomercni ucely.

V pripade zameru vyuzit font komercne me prosim kontaktujte na emailu: krraaa@yahoo.com a dohodneme se na cene.

Pokud mi budete psat, nezapomente do predmetu zpravy napsat "Urania Czech".

Ocenim i vase komentare nebo obrazky vasi tvorby s vyuzitim meho fontu, ktere m�zete zasilat na stejnou adresu.

Klidne font dale distribuujte, ale pouze spolecne s timto textem! V zadnem pripade font nijak neme�te a neupravujte.

Mejte se fajn!

PS. Kdyz zmacknete alt-1, ukaze se logo vyrobce psaciho stroje Urania.
